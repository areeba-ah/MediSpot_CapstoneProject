/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.google.firebase.firestore;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.google.firebase.firestore";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String TARGET_BACKEND = "emulator";
  // Field from default config.
  public static final String TARGET_DATABASE_ID = "(default)";
  // Field from default config.
  public static final String VERSION_NAME = "25.1.2";
}
